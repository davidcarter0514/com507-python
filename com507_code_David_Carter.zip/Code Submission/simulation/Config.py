class Config:
    sim_name = 'Simulator'
    initial_sim_speed = 4
    min_sim_speed = 1
    max_sim_speed = 5
    world_height = 20
    world_width = 20