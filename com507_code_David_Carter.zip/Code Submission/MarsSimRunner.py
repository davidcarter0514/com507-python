from marssim.MarsSim import MarsSim

mars_sim = MarsSim()
mars_sim.run()